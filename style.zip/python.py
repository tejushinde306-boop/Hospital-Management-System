from flask import Flask, render_template, request, jsonify, send_file
import sqlite3, datetime, csv, io

app = Flask(__name__)

def init_db():
    conn = sqlite3.connect('hospital.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS patients
        (id TEXT PRIMARY KEY, date TEXT, name TEXT, age INTEGER, contact TEXT, address TEXT, blood TEXT,
        disease TEXT, category TEXT, status TEXT, doctor TEXT, room TEXT, advance REAL, medicine REAL,
        final REAL, total REAL, next_checkup TEXT, discharge TEXT)''')
    conn.commit(); conn.close()

init_db()

@app.route('/')
def home():
    return render_template('index.html') # put the 3 files in templates folder

@app.route('/api/patients', methods=['GET','POST','PUT','DELETE'])
def api_patients():
    conn = sqlite3.connect('hospital.db'); c = conn.cursor()
    if request.method == 'GET':
        c.execute("SELECT * FROM patients"); data = c.fetchall(); conn.close(); return jsonify(data)
    if request.method == 'POST':
        data = request.json; c.execute("INSERT INTO patients VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", data)
    if request.method == 'PUT':
        data = request.json; c.execute("UPDATE patients SET... WHERE id=?", data)
    if request.method == 'DELETE':
        c.execute("DELETE FROM patients WHERE id=?", (request.json['id'],))
    conn.commit(); conn.close(); return jsonify({"status":"ok"})

if __name__ == '__main__':
    app.run(debug=True)