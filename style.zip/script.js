let patients = JSON.parse(localStorage.getItem('patients')) || [];
let selectedId = null;
const cols = ["ID","Date","Name","Age","Contact","Address","Blood","Disease","Category","Status","Doctor","Room","Advance","Medicine","Final","Total","NextCheckup","Discharge"];

document.getElementById('date').valueAsDate = new Date();

function checkLogin(){
    if(document.getElementById('password').value === "HMS"){
        document.getElementById('loginPage').style.display = 'none';
        document.getElementById('mainApp').style.display = 'block';
        showPatients(); updateDashboard();
    } else alert("Invalid Password");
}
function logout(){ location.reload(); }

function saveData(){ localStorage.setItem('patients', JSON.stringify(patients)); }
function generateId(){ return `SPARC-${new Date().toISOString().slice(0,10).replace(/-/g,'')}-${Math.random().toString(16).substr(2,6).toUpperCase()}`; }

function calcTotal(){
    let total = Number(document.getElementById('advance').value||0) + Number(document.getElementById('medicine').value||0) + Number(document.getElementById('final').value||0);
    document.getElementById('totalBill').value = total;
}

function clearForm(){
    document.querySelectorAll('.form-group input,.form-group select').forEach(el => { if(!el.readOnly) el.value = ""; });
    document.getElementById('pid').value = "Auto Generated";
    document.getElementById('date').valueAsDate = new Date();
    document.getElementById('totalBill').value = "0";
    selectedId = null;
}

function addPatient(){
    if(!document.getElementById('name').value ||!document.getElementById('contact').value) return alert("Name and Contact required");
    let pid = generateId();
    let data = [
        pid, document.getElementById('date').value,
        document.getElementById('name').value, document.getElementById('age').value, document.getElementById('contact').value,
        document.getElementById('address').value, document.getElementById('blood').value, document.getElementById('disease').value,
        document.getElementById('category').value, document.getElementById('status').value, document.getElementById('doctor').value,
        document.getElementById('room').value, document.getElementById('advance').value||"0", document.getElementById('medicine').value||"0",
        document.getElementById('final').value||"0", document.getElementById('totalBill').value,
        document.getElementById('next').value, document.getElementById('discharge').value
    ];
    patients.push(data); saveData(); alert(`Patient Added! ID: ${pid}`); clearForm(); showPatients(); updateDashboard();
}

function updatePatient(){
    if(!selectedId) return alert("Select a patient from table first");
    let idx = patients.findIndex(p => p[0] === selectedId);
    let old = patients[idx];
    let getVal = (id, i) => document.getElementById(id).value || old[i];
    let newData = [
        old[0], getVal('date',1), getVal('name',2), getVal('age',3), getVal('contact',4), getVal('address',5),
        getVal('blood',6), getVal('disease',7), getVal('category',8), getVal('status',9), getVal('doctor',10), getVal('room',11),
        getVal('advance',12), getVal('medicine',13), getVal('final',14), "0", getVal('next',16), getVal('discharge',17)
    ];
    newData[15] = Number(newData[12]) + Number(newData[13]) + Number(newData[14]);
    patients[idx] = newData; saveData(); alert("Patient Updated"); clearForm(); showPatients(); updateDashboard();
}

function deletePatient(){
    if(!selectedId) return;
    if(confirm("Delete this patient?")){
        patients = patients.filter(p => p[0]!== selectedId); saveData(); clearForm(); showPatients(); updateDashboard();
    }
}

function showPatients(){
    let thead = "<tr>" + cols.map(c=>`<th>${c}</th>`).join("") + "</tr>";
    document.getElementById('tableHead').innerHTML = thead;
    let tbody = patients.map(p=>{
        let tag = p[9]==='Admitted'?'admitted':p[9]==='Discharged'?'discharged':'ward';
        return `<tr class="${tag}" onclick="loadRow('${p[0]}')">` + p.map(d=>`<td>${d}</td>`).join("") + "</tr>";
    }).join("");
    document.getElementById('tableBody').innerHTML = tbody;
}

function loadRow(id){
    selectedId = id; let p = patients.find(x=>x[0]===id);
    document.getElementById('pid').value = p[0];
    document.getElementById('date').value = p[1];
    document.getElementById('name').value = p[2]; document.getElementById('age').value = p[3]; document.getElementById('contact').value = p[4];
    document.getElementById('address').value = p[5]; document.getElementById('blood').value = p[6]; document.getElementById('disease').value = p[7];
    document.getElementById('category').value = p[8]; document.getElementById('status').value = p[9]; document.getElementById('doctor').value = p[10];
    document.getElementById('room').value = p[11]; document.getElementById('advance').value = p[12]; document.getElementById('medicine').value = p[13];
    document.getElementById('final').value = p[14]; calcTotal(); document.getElementById('next').value = p[16]; document.getElementById('discharge').value = p[17];
}

function searchPatient(){
    let q = document.getElementById('search').value.toLowerCase();
    let filtered = patients.filter(p => p.join(" ").toLowerCase().includes(q));
    document.getElementById('tableBody').innerHTML = filtered.map(p=>`<tr onclick="loadRow('${p[0]}')">` + p.map(d=>`<td>${d}</td>`).join("") + "</tr>").join("");
}

function updateDashboard(){
    document.getElementById('total').innerText = patients.length;
    document.getElementById('admitted').innerText = patients.filter(p=>p[9]==='Admitted').length;
    document.getElementById('discharged').innerText = patients.filter(p=>p[9]==='Discharged').length;
    document.getElementById('icu').innerText = patients.filter(p=>p[8]==='ICU - Serious').length;
    let revenue = patients.reduce((sum,p)=>sum+Number(p[15]),0);
    document.getElementById('revenue').innerText = `₹${revenue.toLocaleString()}`;
}

function exportCSV(){
    let csv = cols.join(",") + "\n" + patients.map(p=>p.join(",")).join("\n");
    let blob = new Blob([csv], {type: 'text/csv'});
    let a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = "HMS_Patients.csv"; a.click();
}

function printSlip(){
    if(!selectedId) return alert("Select a patient from table first");
    let p = patients.find(x=>x[0]===selectedId);
    let win = window.open('', '', 'height=800,width=900');
    win.document.write(`
        <html><head><title>Bill - ${p[0]}</title>
        <style>body{font-family:Arial;padding:30px}.head{text-align:center;color:#00695C}.row{display:flex;justify-content:space-between;margin:6px 0} table{width:100%;margin-top:15px}</style>
        </head><body>
        <h1 class="head">HMS-SPARC International Hospital</h1><p class="head">Patient Bill & Discharge Slip</p><hr>
        <div class="row"><b>Patient ID:</b><span>${p[0]}</span><b>Date:</b><span>${p[1]}</span></div>
        <div class="row"><b>Name:</b><span>${p[2]}</span><b>Age:</b><span>${p[3]}</span></div>
        <div class="row"><b>Contact:</b><span>${p[4]}</span><b>Blood:</b><span>${p[6]}</span></div>
        <div class="row"><b>Category:</b><span>${p[8]}</span><b>Status:</b><span>${p[9]}</span></div>
        <div class="row"><b>Doctor:</b><span>${p[10]}</span><b>Room:</b><span>${p[11]}</span></div>
        <hr><h3>Payment Details</h3>
        <div class="row"><span>Advance Payment</span><span>₹${p[12]}</span></div>
        <div class="row"><span>Medicine Payment</span><span>₹${p[13]}</span></div>
        <div class="row"><span>Final Payment</span><span>₹${p[14]}</span></div>
        <div class="row"><b>Total Bill</b><b>₹${p[15]}</b></div>
        <hr><p><b>Next Checkup:</b> ${p[16]}</p><p><b>Discharge Summary:</b> ${p[17]}</p>
        <br><br><p style="text-align:right">Authorized Signature: ___________</p>
        <script>window.print();<\/script>
        </body></html>
    `);
    win.document.close();
}